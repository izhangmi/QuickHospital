//
//  TableHeader.h
//  团购
//
//  Created by bear on 16/3/9.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Banner : UIView


@property (nonatomic, copy) void(^jump2VC)(UIViewController * targetVc);
@end
