//
//  DiseaseListController.h
//  快医
//
//  Created by 付凯琪 on 16/5/12.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiseaseListController : UIViewController

@end
