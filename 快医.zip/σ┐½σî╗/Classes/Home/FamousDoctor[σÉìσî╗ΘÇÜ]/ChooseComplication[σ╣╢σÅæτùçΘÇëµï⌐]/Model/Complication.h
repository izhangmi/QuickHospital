//
//  Complication.h
//  快医
//
//  Created by bear on 16/5/12.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+YYModel.h"

@interface Complication : NSObject


@property (nonatomic, assign) NSInteger complication_id;

@property (nonatomic, copy) NSString *complication_name;



@end

