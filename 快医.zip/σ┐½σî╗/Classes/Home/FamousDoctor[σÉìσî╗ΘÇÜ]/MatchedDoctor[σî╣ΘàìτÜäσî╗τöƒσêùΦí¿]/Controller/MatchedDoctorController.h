//
//  MatchedDoctorController.h
//  快医
//
//  Created by bear on 16/5/12.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MatchedDoctorController : UITableViewController



+(instancetype)matchedDoctorController;
@end
