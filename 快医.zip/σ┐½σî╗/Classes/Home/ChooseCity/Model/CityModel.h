//
//  CityModel.h
//  快医
//
//  Created by bear on 16/5/13.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+YYModel.h"

@interface CityModel : NSObject
@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *pinyin;
@end
