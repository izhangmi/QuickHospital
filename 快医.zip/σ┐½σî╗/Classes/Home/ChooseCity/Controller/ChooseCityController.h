//
//  ChooseCityController.h
//  快医
//
//  Created by bear on 16/5/13.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChooseCityController : UIViewController

@property (nonatomic, copy) void (^handlerBlock)(NSString* cityName);

@end
