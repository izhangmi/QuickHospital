//
//  CCNavigationController.h
//  hedaAssistant
//
//  Created by bear on 16/3/24.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CCNavigationController : UINavigationController

@end
