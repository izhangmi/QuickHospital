//
//  doctorConcernedTableView.h
//  收藏03
//
//  Created by 朱宁MacPro on 16/5/12.
//  Copyright © 2016年 朱宁MacPro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface doctorConcernedTableView : UITableView

@property (nonatomic, copy) void(^jumpToTChatVc)();

@end
