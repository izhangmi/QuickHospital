//
//  TableHeaderView.h
//  2.第二题-tableView
//
//  Created by 柯平常 on 16/5/5.
//  Copyright © 2016年 柯平常. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableHeaderView : UIView

@property (nonatomic, copy) NSString *userName;

+(instancetype)headerView;

@end
