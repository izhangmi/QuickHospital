//
//  KKMYTAllayViewController.h
//  快医
//
//  Created by 柯平常 on 16/5/10.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KKMYTAllayViewController : UIViewController

@end
