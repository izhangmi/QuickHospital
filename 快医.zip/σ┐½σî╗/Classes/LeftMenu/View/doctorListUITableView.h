//
//  doctorListUITableView.h
//  Doctor List
//
//  Created by 张少霞 on 16/5/10.
//  Copyright © 2016年 zsx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface doctorListUITableView : UITableView

@end
