//
//  KKMedicalrecordTableView.h
//  快医
//
//  Created by 朱宁MacPro on 16/5/13.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KKMedicalrecordTableView : UITableView

@end
