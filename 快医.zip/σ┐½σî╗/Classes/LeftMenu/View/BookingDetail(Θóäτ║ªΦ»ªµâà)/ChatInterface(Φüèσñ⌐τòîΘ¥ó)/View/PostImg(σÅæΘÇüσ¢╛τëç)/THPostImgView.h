//
//  THPostImgView.h
//  快医
//
//  Created by litianhao on 16/5/12.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface THPostImgView : UIView

@property (nonatomic,copy) void(^postHisCallback) (void);

@end
