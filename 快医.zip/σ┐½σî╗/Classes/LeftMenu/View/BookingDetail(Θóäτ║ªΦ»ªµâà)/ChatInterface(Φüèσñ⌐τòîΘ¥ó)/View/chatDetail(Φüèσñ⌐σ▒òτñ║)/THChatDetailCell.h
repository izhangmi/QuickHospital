//
//  THChatDetailCell.h
//  快医
//
//  Created by litianhao on 16/5/12.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <UIKit/UIKit.h>

@class THChatCellModel ;

@interface THChatDetailCell : UITableViewCell

@property (nonatomic,strong) THChatCellModel *model;

@end
