//
//  THBuySeviceCell.h
//  快医
//
//  Created by litianhao on 16/5/13.
//  Copyright © 2016年 bear. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "THBuySeviceModel.h"

@interface THBuySeviceCell : UITableViewCell

@property (nonatomic,strong) THBuySeviceModel *model;

@end
