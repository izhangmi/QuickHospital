//
//  DoctorCell.h
//  Doctor
//
//  Created by 张少霞 on 16/5/11.
//  Copyright © 2016年 zsx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DoctorModel.h"
@interface DoctorCell : UITableViewCell

@property (nonatomic ,strong)DoctorModel *model;


@end
