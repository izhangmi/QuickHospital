//
//  PayDetailsTableViewCell.h
//  支付明细
//
//  Created by 朱宁MacPro on 16/5/10.
//  Copyright © 2016年 朱宁MacPro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PayDetailsModel.h"
@interface PayDetailsTableViewCell : UITableViewCell

@property(nonatomic,strong)PayDetailsModel *model;
@end
